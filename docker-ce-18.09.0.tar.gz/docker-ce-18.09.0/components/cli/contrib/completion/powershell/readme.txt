See https://github.com/matt9ucci/DockerCompletion
or https://github.com/samneirinck/posh-docker
