package main

import _ "github.com/docker/cli/cli/winresources"
